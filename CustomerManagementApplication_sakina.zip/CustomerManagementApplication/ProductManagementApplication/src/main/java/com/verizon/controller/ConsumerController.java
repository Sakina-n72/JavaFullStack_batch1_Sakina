package com.verizon.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.verizon.model.Consumer;
import com.verizon.service.ConsumerService;

@RestController
@RequestMapping("/consumers")
public class ConsumerController {

    @Autowired
    private ConsumerService consumerService;

    @GetMapping
    public ResponseEntity<List<Consumer>> getConsumerDetails() {
        List<Consumer> consumers = consumerService.getAllConsumers();
        return new ResponseEntity<>(consumers, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Consumer> addConsumerDetails(@RequestBody Consumer consumer) {
        Consumer savedConsumer = consumerService.addConsumer(consumer);
        return new ResponseEntity<>(savedConsumer, HttpStatus.CREATED);
    }

    @PutMapping("/{cid}")
    public ResponseEntity<Consumer> updateConsumerEmail(@PathVariable Integer cid, @RequestBody String email) {
        try {
            Consumer updatedConsumer = consumerService.updateConsumerEmail(cid, email);
            return new ResponseEntity<>(updatedConsumer, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{cid}")
    public ResponseEntity<Void> deleteConsumer(@PathVariable Integer cid) {
        consumerService.deleteConsumer(cid);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
