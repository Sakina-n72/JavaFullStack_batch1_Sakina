package com.verizon.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.verizon.dao.ConsumerDao;
import com.verizon.model.Consumer;

@Service
public class ConsumerService {

    @Autowired
    private ConsumerDao consumerDao;

    // Add a new consumer
    public Consumer addConsumer(Consumer consumer) {
        return consumerDao.save(consumer);
    }

    // Get all consumers
    public List<Consumer> getAllConsumers() {
        return consumerDao.findAll();
    }

    // Update consumer email by id
    public Consumer updateConsumerEmail(Integer id, String email) {
        Consumer consumer = consumerDao.findById(id).orElseThrow(() -> new RuntimeException("Consumer not found"));
        consumer.setEmail(email);
        return consumerDao.save(consumer);
    }

    // Delete consumer by id
    public void deleteConsumer(Integer id) {
        Consumer consumer = consumerDao.findById(id).orElseThrow(() -> new RuntimeException("Consumer not found"));
        consumerDao.delete(consumer);
    }
}
